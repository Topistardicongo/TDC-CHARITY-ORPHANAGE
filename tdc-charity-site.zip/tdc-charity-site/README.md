# TDC Charity & Orphanage Website

A clean, multi-page static website for TDC Charity & Orphanage.  
Ready to deploy on any static host (Netlify, Vercel, GitHub Pages, cPanel, etc.).

## Pages
- `index.html` — Home
- `about.html` — About Us
- `creativity.html` — Creativity & Innovation Hub
- `gallery.html` — Impact Gallery
- `news.html` — News & Updates
- `store.html` — TDC Store
- `contact.html` — Contact & Volunteer

## Features
- Responsive design (Tailwind CSS)
- Donation modal (MTN, Airtel, PesaPal, Card)
- Shopping cart + checkout (client-side)
- Gallery lightbox
- Contact form
- Floating “Donate a Dime” button
- Lucide icons

## Deploy in 3 steps
1. Upload the entire folder (or just the HTML files) to your host.
2. Point your domain (or subdomain) to the folder.
3. Replace placeholder contact details:
   - Phone: `+256 700 000 000`
   - Email: `hello@tdccharity.org`
   - WhatsApp link in `contact.html`

## Optional next steps
- Add real photos to gallery/store
- Connect a real payment gateway (PesaPal, Flutterwave, etc.)
- Add a backend form handler for contact messages
- Buy a domain and point it here

## Tech
- Pure HTML + Tailwind (CDN)
- Alpine.js (for modals & cart)
- Lucide Icons
- No build step required

---
Built with 💙 for the children of Uganda  
TDC Charity & Orphanage • 2026
