# TDC Charity & Orphanage Website + Admin Panel

Premium multi-page static website with a full admin dashboard.  
Ready to deploy on any static host (Netlify, Vercel, GitHub Pages, cPanel, etc.).

## Public Pages
- `index.html` — Home
- `about.html` — About Us
- `creativity.html` — Creativity & Innovation Hub
- `gallery.html` — Impact Gallery
- `news.html` — News & Updates
- `store.html` — TDC Store
- `contact.html` — Contact & Volunteer

## Admin Panel
- `admin/index.html` — Premium Admin Dashboard

### Admin Features
- Dashboard with live stats (donations, orders, messages, products)
- Manage Donations (add, view, delete)
- Manage Store Orders
- Manage Products (add, delete)
- Manage News Posts (add, delete)
- Manage Contact Messages
- Manage Gallery Items
- All data saved in browser localStorage (persists across sessions)
- Clean sidebar navigation + responsive design
- Matches the public site theme

**Admin Login:** No password required for this demo version.  
Open `/admin/index.html` directly.

## Deploy in 3 steps
1. Unzip and upload the entire folder to your host.
2. Point your domain to the folder.
3. Access the public site at `/` and admin at `/admin/`.

### Before going live
- Replace placeholder contact details:
  - Phone: `+256 700 000 000`
  - Email: `hello@tdccharity.org`
  - WhatsApp link in `contact.html`
- Add real photos to gallery and product cards
- (Optional) Connect a real backend / payment gateway later

## Tech
- Pure HTML + Tailwind CSS (CDN)
- Alpine.js for interactivity
- Lucide Icons
- No build step required
- Admin data stored in localStorage

---
Built with 💙 for the children of Uganda  
TDC Charity & Orphanage • 2026
